<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kehadiran_struktural extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Login_model');
		$this->load->model('Kehadiran_struktural_model');
        $this->load->helper('Rupiah_helper');
		$this->load->helper('string');
		$this->load->library('Pdf'); 
	}

	public function index(){
		$this->Login_model->getsqurity() ;
		$isi['css'] 	= 'Kehadiran_struktural/Css';
		$isi['content'] = 'Kehadiran_struktural/Kehadiran';
		$isi['ajax'] 	= 'Kehadiran_struktural/Ajax';
		$this->load->view('Template',$isi);
	}
	
	
	public function kehadiran_log(){
		$this->Login_model->getsqurity() ;
		$isi['css'] 	= 'Log_kehadiran/Css';
		$isi['content'] = 'Log_kehadiran/Kehadiran_umana';
		$isi['ajax'] 	= 'Log_kehadiran/Ajax';
		$this->load->view('Template',$isi);
	}
	
    public function encrypt_url($string) {
        $key = '874jzceroier38!@#%*bjkdwdw)'; // Ganti dengan kunci enkripsi yang diinginkan
        $encrypted_string = base64_encode($string . $key);
        $encrypted_string = str_replace(array('+', '/', '='), array('-', '_', ''), $encrypted_string);
        return $encrypted_string;
    }
    
    public function decrypt_url($string) {
        $key = '874jzceroier38!@#%*bjkdwdw)'; // Ganti dengan kunci enkripsi yang diinginkan
        $string = str_replace(array('-', '_'), array('+', '/'), $string);
        $string = base64_decode($string);
        $string = str_replace($key, '', $string);
        return $string;
    }




    public function add($id){
        $decrypted_id = $this->decrypt_url($id);
		$this->Login_model->getsqurity();
		
		// Get periode info (moved from view for security)
		$periode = $this->db->query("
			SELECT l.id_lembaga, kl.id_kehadiran_lembaga, kl.bulan, kl.tahun, l.nama_lembaga 
			FROM kehadiran_lembaga kl, lembaga l
			WHERE kl.id_lembaga = l.id_lembaga 
			  AND kl.id_kehadiran_lembaga = ?
		", [$decrypted_id])->row();
		
		// Get list pegawai aktif (moved from view for security)
		if ($periode) {
			$pegawai = $this->db->query("
				SELECT p.*, u.*, l.*, kb.nama_jabatan
				FROM penempatan p, lembaga l, umana u, ketentuan_barokah kb
				WHERE p.nik = u.nik 
				  AND p.id_lembaga = l.id_lembaga 
				  AND p.id_ketentuan = kb.id_ketentuan 
				  AND l.id_lembaga = ? 
				  AND p.tgl_selesai >= CURDATE()
				ORDER BY kb.id_ketentuan ASC
			", [$periode->id_lembaga])->result();
		} else {
			$pegawai = [];
		}
		
		$isi['css'] 	= 'Kehadiran_struktural/Css';
		$isi['content'] = 'Kehadiran_struktural/Add_kehadiran';
		$isi['ajax'] 	= 'Kehadiran_struktural/Ajax';
		$isi['kode'] 	= $decrypted_id;
		$isi['periode'] = $periode;
		$isi['pegawai'] = $pegawai;
		
		$this->load->view('Template',$isi);
	}
	
	


	public function data_list()
	{
		$this->load->helper('url');
		if($this->session->userdata('jabatan') == 'AdminLembaga'){
			$lembaga = $this->session->userdata('lembaga');
			$list = $this->db->query("SELECT nama_lembaga, id_kehadiran_lembaga, kehadiran_lembaga.status, kehadiran_lembaga.bulan, kehadiran_lembaga.tahun, penempatan.nik, COUNT(penempatan.id_penempatan) as jml FROM lembaga, kehadiran_lembaga, penempatan WHERE kehadiran_lembaga.id_lembaga = lembaga.id_lembaga and penempatan.id_lembaga = kehadiran_lembaga.id_lembaga and lembaga.id_lembaga = $lembaga and kehadiran_lembaga.kategori = 'Struktural' GROUP BY kehadiran_lembaga.id_kehadiran_lembaga order by kehadiran_lembaga.id_kehadiran_lembaga desc ")->result();
		} else {
			$list = $this->db->query("SELECT nama_lembaga, id_kehadiran_lembaga, kehadiran_lembaga.status, kehadiran_lembaga.bulan, kehadiran_lembaga.tahun, penempatan.nik, COUNT(penempatan.id_penempatan) as jml FROM lembaga, kehadiran_lembaga, penempatan WHERE kehadiran_lembaga.id_lembaga = lembaga.id_lembaga and penempatan.id_lembaga = kehadiran_lembaga.id_lembaga and kehadiran_lembaga.kategori = 'Struktural' GROUP BY kehadiran_lembaga.id_kehadiran_lembaga order by kehadiran_lembaga.id_kehadiran_lembaga desc ")->result();
		}
		$no =1;
		$data = array();
		foreach ($list as $datanya) {
			$encrypted_id = $this->encrypt_url($datanya->id_kehadiran_lembaga);
			$row = array();
			$row[] = $no++;
			$row[] = htmlentities($datanya->nama_lembaga);
			$row[] = htmlentities($datanya->jml)." org";
			$row[] = htmlentities($datanya->bulan);
			$row[] = htmlentities($datanya->tahun);
			$jabatanUser = $this->session->userdata('jabatan');

			if ($datanya->status == 'Belum') {
				$row[] = "<span class='badge badge-secondary'>Belum diisi <i class='fa fa-times ms-1'></i></span>";
			
				$aksi  = '<a type="button" class="btn btn-outline-secondary btn-sm" href="#" ';
				$aksi .= 'title="Rekap" onclick="rekap(\''.$encrypted_id.'\')">';
				$aksi .= '<i class="mdi mdi-file-document-box mr-1"></i> Isi Rekap Kehadiran</a>';
			
				$row[] = $aksi;
			
			} elseif ($datanya->status == "Sudah") {
				$row[] = "<span class='badge badge-danger'>Belum dikirim <i class='fa fa-exclamation-circle ms-1'></i></span>";
			
				// rangkai aksi dasar
				$aksi  = '<a type="button" class="btn btn-success btn-xs" href="Validasi_struktural/koreksi/'.$encrypted_id.'">';
				$aksi .= '<i class="mdi mdi-checkbox-marked-circle mr-1"></i> Cek Barokah</a> ';
				
			
				// tambahkan tombol reset hanya untuk SuperAdmin/Evaluasi
				if (in_array($jabatanUser, ['SuperAdmin', 'Evaluasi'])) {
					$aksi .= ' - <button type="button" class="btn btn-sm btn-outline-danger ml-2 btn-reset" '.
							 'data-id="'.$datanya->id_kehadiran_lembaga.'" '.
							 'data-status="'.$datanya->status.'">'.
							 '<i class="fa fa-undo mr-1"></i> Reset</button>';
				}
			
				$row[] = $aksi;
			
			} elseif ($datanya->status == "Terkirim" || $datanya->status == "acc") {
				$row[] = "<span class='badge badge-warning text-dark'>Sedang dikoreksi <i class='fa fa-sync ms-1'></i></span>";
			
				$aksi  = '<a type="button" class="btn btn-success btn-xs" href="Validasi_struktural/koreksi/'.$encrypted_id.'">';
				$aksi .= '<i class="mdi mdi-checkbox-marked-circle mr-1"></i> Cek Barokah</a> ';
			
				if (in_array($jabatanUser, ['SuperAdmin', 'Evaluasi'])) {
					$aksi .= ' - <button type="button" class="btn btn-sm btn-outline-danger ml-2 btn-reset" '.
							 'data-id="'.$datanya->id_kehadiran_lembaga.'" '.
							 'data-status="'.$datanya->status.'">'.
							 '<i class="fa fa-undo mr-1"></i> Reset</button>';
				}
			
				$row[] = $aksi;
			
			} else {
				$row[] = "<span class='badge badge-success'>Sudah transfer <i class='fa fa-check ms-1'></i></span>";
			
				// Redirect ke Laporan Per Lembaga untuk data yang sudah selesai (menggunakan snapshot dari total_barokah)
				$aksi  = '<a type="button" class="btn btn-info btn-sm" href="'.site_url('laporan_lembaga/rincian/'.$encrypted_id).'">';
				$aksi .= '<i class="mdi mdi-file-document-box mr-1"></i> Lihat Laporan Final</a>';
				if (in_array($jabatanUser, ['SuperAdmin', 'Evaluasi'])) {
					$aksi .= ' - <button type="button" class="btn btn-sm btn-outline-danger ml-2 btn-reset" '.
							 'data-id="'.$datanya->id_kehadiran_lembaga.'" '.
							 'data-status="'.$datanya->status.'">'.
							 '<i class="fa fa-undo mr-1"></i> Reset</button>';
				}
				$row[] = $aksi;
			}
			//add html for action
			
		    $data[] = $row;
		}
		$output = array("data" => $data);
		echo json_encode($output);
	}
	
	
	public function data_list_log()
	{
		$this->load->helper('url');
		$list = $this->db->get('kehadiran')->result();
		$no =1;
		$data = array();
		foreach ($list as $datanya) {
			$row = array();
			$row[] = $no++;
			$row[] = htmlentities($datanya->bulan)." - ".htmlentities($datanya->tahun);
			$row[] = htmlentities($datanya->id_penempatan);
			$row[] = htmlentities($datanya->id_kehadi);
			$row[] = htmlentities($datanya->jumlah_hadir);
			$row[] = htmlentities($datanya->tgl_input);
			$row[] = '<a type="button" class="btn btn-outline-success btn-sm" href="#" 
			title="Rekap" onclick="edit('."'".$datanya->id_kehadiran."'".')"><i class="mdi mdi-pencil mr-1" ></i> Edit</a> - 
			<a type="button" class="btn btn-outline-danger btn-sm" href="hapus/'.$datanya->id_kehadiran.'">
			<i class="mdi mdi-delete mr-1" ></i> Hapus</a>';
		
			//add html for action
			
		    $data[] = $row;
		}
		$output = array("data" => $data);
		echo json_encode($output);
	}
	
	public function ajax_log_add()
	{
		$data = array(
            'id_kehadiran' 	    => '',
            'bulan' 			=> $this->input->post('bulan'),
            'tahun' 			=> $this->input->post('tahun'),
            'id_penempatan' 	=> $this->input->post('id_penempatan'),
			'jumlah_hadir' 		=> $this->input->post('jumlah_hadir'),
        );

		$simpan = $this->kehormatan_model->create('kehadiran',$data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update(){
        // $this->_validate_edit();
       $data = array(
			'id_penempatan' 	=> $this->input->post('penempatan'), 	
			'id_kehadi' 	=> $this->input->post('kehadiran'), 
			'jumlah_hadir' 	=> $this->input->post('jumlah'),   
        );
        
		$this->db->update('kehadiran',$data, array('id_kehadiran' => $this->input->post('id_kehadiran')));
		echo json_encode(array("status" => TRUE));
	}

	
	public function ajax_edit_log($id)
	{
		$query = $this->db->get_where('kehadiran', array('id_kehadiran' => $id));

		if ($query->num_rows() > 0) {
			$row = $query->row();
			// Assuming $row contains the data for the specific record
			echo json_encode($row);
		} else {
			// If the record with the given $id is not found
			echo json_encode(array('error' => 'Record not found'));
		}
	}


	public function hapus($id)
	{
		$this->db->where('id_kehadiran', $id)->delete('kehadiran');
		
		// Set pesan notifikasi menggunakan flashdata
		$this->session->set_flashdata('success', 'Data berhasil dihapus.');
		
		// Redirect ke halaman yang diinginkan
		redirect('kehadiran/kehadiran_log');
	}

	public function rekap_list()
	{
		$list = $this->db->query("SELECT * from penempatan, lembaga, umana where penempatan.nik = umana.nik and penempatan.id_lembaga = lembaga.id_lembaga and lembaga.id_lembaga = 1 ")->result();
		$no =1;
		$data = array();
		foreach ($list as $datanya) {
			
			$row = array();
			$row[] = $datanya->nik;
			$row[] = htmlentities($datanya->nama_lengkap);
            $row[] = htmlentities($datanya->id_ketentuan);
			$row[] = htmlentities($datanya->nama_lembaga);
			$row[] = "<input type='text' name='hadir[]' class='form-control'> <input type='hidden' name='nik_umana[]' value=".$datanya->nik.">";
			$row[] = "<input type='text' class='form-control'>";
			$row[] = "<input type='text' class='form-control'>";
			//add html for action
			$row[] = '<a type="button" class="btn btn-outline-success btn-sm" href="#" 
			title="Rekap" onclick="rekap('."'".$datanya->id_lembaga."'".')"><i class="mdi mdi-file-document-box mr-1" ></i> Rekap Kehadiran</a>';
		    $data[] = $row;
		}
		$output = array("data" => $data);
		echo json_encode($output);
	}

	public function ajax_add()
	{
		$this->Login_model->getsqurity();
	
		// Ambil input dasar
		$id_kehadiran_lembaga = $this->input->post('id_kehadiran_lembaga');
		$bulan  = $this->input->post('bulan');
		$tahun  = $this->input->post('tahun');
		$id_penempatan   = $this->input->post('id_penempatan');
		$jumlah_hadir    = $this->input->post('jumlah_hadir');
		$jumlah_tugas    = $this->input->post('jumlah_tugas'); // New input
		$jumlah_izin     = $this->input->post('jumlah_izin');
		$jumlah_sakit    = $this->input->post('jumlah_sakit');
	
		// Validasi minimal
		if (empty($id_kehadiran_lembaga) || empty($bulan) || empty($tahun)) {
			echo json_encode(["status"=>false, "message"=>"Konteks periode tidak lengkap."]);
			return;
		}
	
		// Wajib file PDF
		if (empty($_FILES['file']['name'])) {
			echo json_encode([
				"status"  => false,
				"message" => "File absensi (PDF) wajib diunggah sebelum menyimpan."
			]);
			return;
		}
	
		// Upload file
		$uploadedFile = $this->_do_upload();
	
		// Susun data batch
		$data = [];
		if (is_array($id_penempatan)) {
			foreach ($id_penempatan as $i => $idp) {
			// Ambil nilai, default 0 jika kosong
			$hadir = isset($jumlah_hadir[$i]) && $jumlah_hadir[$i] !== '' ? (int)$jumlah_hadir[$i] : 0;
			$tugas = isset($jumlah_tugas[$i]) && $jumlah_tugas[$i] !== '' ? (int)$jumlah_tugas[$i] : 0; // New var
			$izin  = isset($jumlah_izin[$i]) && $jumlah_izin[$i] !== '' ? (int)$jumlah_izin[$i] : 0;
			$sakit = isset($jumlah_sakit[$i]) && $jumlah_sakit[$i] !== '' ? (int)$jumlah_sakit[$i] : 0;
			
			// Normalisasi: tidak boleh negatif
			$hadir = max(0, $hadir);
			$tugas = max(0, $tugas);
			$izin  = max(0, $izin);
			$sakit = max(0, $sakit);
	
				$data[] = [
					'bulan'         => $bulan,
					'tahun'         => $tahun,
					'id_penempatan' => $idp,
					'id_kehadi'     => $id_kehadiran_lembaga,
					'jumlah_hadir'  => $hadir,
					'jumlah_tugas'  => $tugas, // Insert into DB
					'jumlah_izin'   => $izin,
					'jumlah_sakit'  => $sakit,
				];
			}
		}
	
		// Transaksi
		$this->db->trans_begin();
	
		// Hapus data lama (idempotent)
		$this->db->where('id_kehadi', $id_kehadiran_lembaga)->delete('kehadiran');
	
		if (!empty($data)) {
			$this->db->insert_batch('kehadiran', $data);
		}
	
		// Update status dan file ke tabel periode
		$this->db->where('id_kehadiran_lembaga', $id_kehadiran_lembaga)
				 ->update('kehadiran_lembaga', [
					'status' => 'Sudah',
					'file'   => $uploadedFile
				 ]);
	
		// Commit transaksi
		if ($this->db->trans_status() === FALSE) {
			$this->db->trans_rollback();
			echo json_encode(["status"=>false, "message"=>"Gagal menyimpan data kehadiran."]);
		} else {
			$this->db->trans_commit();
			echo json_encode(["status"=>true, "message"=>"Rekap kehadiran berhasil disimpan."]);
		}
	}
	

	

	
	public function update_kirim(){
        // $this->_validate_edit();
       $data = array(
			'status' 	=> "Terkirim", 	
		);
        
		$this->db->update('kehadiran_lembaga',$data, array('id_kehadiran_lembaga' => $this->input->post('id_kehadiran_lembaga')));
		echo json_encode(array("status" => TRUE));
	}
	
	public function koreksi($id){
	    $decrypted_id = $this->decrypt_url($id);
		$list = $this->db->query("select lembaga.id_lembaga, id_kehadiran, kehadiran_lembaga.status, ketentuan_barokah.id_ketentuan, id_bidang, tunj_anak, tunj_mp, umana.gelar_depan, umana.gelar_belakang, kehormatan, kehadiran_lembaga.file, tunj_kel, id_kehadiran_lembaga, nama_lengkap, nama_jabatan, status_nikah, tmt_struktural, kehadiran.id_penempatan, kehadiran.bulan, kehadiran.tahun, jumlah_hadir, nama_lembaga, barokah, nominal_transport from umana, penempatan, kehadiran, kehadiran_lembaga, lembaga, ketentuan_barokah, transport WHERE 
		kehadiran_lembaga.id_kehadiran_lembaga = kehadiran.id_kehadi and 
		penempatan.id_penempatan = kehadiran.id_penempatan and 
		penempatan.nik = umana.nik and 
		penempatan.id_lembaga = lembaga.id_lembaga and 
		penempatan.id_ketentuan = ketentuan_barokah.id_ketentuan and 
		penempatan.kategori_trans = transport.id_transport and 
		DATEDIFF(NOW(), penempatan.tgl_mulai) < penempatan.tgl_selesai and
		kehadiran_lembaga.id_kehadiran_lembaga = $decrypted_id order by ketentuan_barokah.id_ketentuan asc ")->result();
		$no = 1;
		$tunkel_get = $this->db->get('tunkel')->result();
		$tunj_anak_get = $this->db->get('tunjanak')->result();
		// $kehormatan = $this->db->query('select * from ');
		$this->Login_model->getsqurity() ;

		$isi['css'] 	= 'Kehadiran_struktural/Css';
		$isi['content'] = 'Validasi/Jumlah_kehadiran';
		$isi['ajax'] 	= 'Validasi/Ajax';
		$isi['isitunkel']  = $tunkel_get;
		$isi['isitunj_anak']  = $tunj_anak_get;
		$isi['isilist']  = $list;
		$this->load->view('Template',$isi);
		
	}
	
	
	public function get_absen($id)
	{
		$this->load->helper('url');
		$data_elemen = $this->Kehadiran_struktural_model->get_lembaga($id);
		$list = $this->Kehadiran_struktural_model->get_datatables_rincian($id);
		$data = array();
    	$no=1;
		$html_item = '';
		foreach ($list as $sow) {
			$html_item .= '<tr>';
			$html_item .= '<td><h6>'.$no++.'</h6></td>';
			$html_item .= '<td><h6>'.$sow->nama_lengkap.'</h6> <input type="hidden" name="id_kehadiran[]" value="'.$sow->id_kehadiran.'" ></td>';
			$html_item .= '<td><h6>'.$sow->nama_jabatan.'</h6></td>';
			$html_item .= '<td><h6>'.$sow->jumlah_hadir.'</h6><input type="hidden" name="diterima[]" value="'.rupiah($sow->diterima).'" ></td>';
			$html_item .= '</tr>';
		}
		$this->output->set_output(json_encode(array("data_elemen" => $data_elemen, "html_item" => $html_item)));
	}
	
	
	public function get_total_absen($id)
	{
		$this->load->helper('url');
		$data_elemen = $this->Kehadiran_struktural_model->get_lembaga($id);
		$list = $this->Kehadiran_struktural_model->get_jumlah_hadir($id);
		$data = array();
    	$no=1;
		$html_item = '';
		foreach ($list as $sow) {
			$html_item .= '<tr>';
			$html_item .= '<td><h6>'.$no++.'</h6></td>';
			$html_item .= '<td><h6>'.$sow->nama_lengkap.'</h6> </td>';
			$html_item .= '<td><h6>'.$sow->nama_jabatan.'</h6></td>';
			$html_item .= '<td><h6>'.$sow->jumlah_hadir.'</h6></td>';
			$html_item .= '</tr>';
		}
		$this->output->set_output(json_encode(array("data_elemen" => $data_elemen, "html_item" => $html_item)));
	}

	public function blanko_add()
	{
		$this->db->where('id_lembaga', $this->input->post('id_lembaga'));
		$this->db->where('bulan', $this->input->post('bulan'));
		$this->db->where('tahun', $this->input->post('tahun'));
		$this->db->where('kategori', 'Struktural');
		$existingData = $this->db->get('kehadiran_lembaga')->row();
	
		if ($existingData) { 
			echo json_encode(array("status" => false));
		}else {
			// $this->_validate();
			$data = array(
				'id_kehadiran_lembaga' 	=> '',
				'id_lembaga' 	=> $this->input->post('id_lembaga'),
				'kategori' 	    => 'Struktural',
				'bulan' 	    => $this->input->post('bulan'),
				'tahun' 	    => $this->input->post('tahun'),
				'status' 	    => 'Belum',
			);
			$simpan = $this->Kehadiran_struktural_model->create('kehadiran_lembaga',$data);
			echo json_encode(array("status" => TRUE));
		}
	}
	


	public function ajax_edit($id)
	{
		$data = $this->Kehadiran_struktural_model->get_by_id($id);
		echo json_encode($data);
	}
	
	public function cetak($id){
		$list2 = $this->db->query("select  nama_pimpinan, id_kehadiran, jabatan_lembaga, ketentuan_barokah.id_ketentuan, id_bidang, tunj_anak, tunj_mp, umana.gelar_depan, umana.gelar_belakang, kehormatan, kehadiran_lembaga.file, tunj_kel, id_kehadiran_lembaga, nama_lengkap, nama_jabatan, status_nikah, tmt_struktural, kehadiran.id_penempatan, kehadiran.bulan, kehadiran.tahun, jumlah_hadir, jumlah_tugas, jumlah_izin, jumlah_sakit, nama_lembaga, barokah, ketentuan_barokah.wajib_hadir, nominal_transport from umana, penempatan, kehadiran, kehadiran_lembaga, lembaga, ketentuan_barokah, transport WHERE 
		kehadiran_lembaga.id_kehadiran_lembaga = kehadiran.id_kehadi and 
		penempatan.id_penempatan = kehadiran.id_penempatan and 
		penempatan.nik = umana.nik and 
		penempatan.id_lembaga = lembaga.id_lembaga and 
		penempatan.id_ketentuan = ketentuan_barokah.id_ketentuan and 
		penempatan.kategori_trans = transport.id_transport and 
		DATEDIFF(NOW(), penempatan.tgl_mulai) < penempatan.tgl_selesai and
		kehadiran_lembaga.id_kehadiran_lembaga = $id order by ketentuan_barokah.id_ketentuan asc, umana.nama_lengkap asc ")->result();
		$tunkel_get = $this->db->get('tunkel')->result();
		$tunj_anak_get = $this->db->get('tunjanak')->result();
		// $kehormatan = $this->db->query('select * from ');
		$this->Login_model->getsqurity() ;

	
		$isi['isitunkel']  = $tunkel_get;
		$isi['isitunj_anak']  = $tunj_anak_get;
		$isi['isilist']  = $list2;
		$this->load->view('Kehadiran_struktural/Cetak',$isi);
	}
	
	

    public function cetak_potongan($id){
		// Query to get the deduction data of the teachers
		$query = "
			SELECT 
				u.nama_lengkap, 
				pot.nama_potongan, 
				pp.nominal_potongan,
				l.nama_lembaga,
				l.id_bidang
			FROM 
				umana u
			JOIN 
				penempatan p ON u.nik = p.nik
			JOIN 
				potongan_umana pp ON pp.id_penempatan = p.id_penempatan
			JOIN 
				potongan pot ON pp.jenis_potongan = pot.id_potongan
			JOIN
				lembaga l ON p.id_lembaga = l.id_lembaga
			WHERE 
				pp.max_periode_potongan >= DATE_FORMAT(NOW(), '%Y-%m-01')
				AND p.id_lembaga = ?
			ORDER BY u.nama_lengkap ASC
		";
	
		// Execute the query with parameter binding
		$list2 = $this->db->query($query, array($id))->result();
	
		// Login security
		$this->Login_model->getsqurity();
	
		// Store the query result in an array to send to the view
		$isi['isilist'] = $list2;
	
		// Load the view with the prepared data
		$this->load->view('Kehadiran_struktural/Potongan_struktural', $isi);
	}


	public function _do_upload()
{
    $date = new DateTime();

    // Folder target sejajar index.php → /uploads
    $uploadDir = rtrim(FCPATH, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'upload' . DIRECTORY_SEPARATOR;

    // Buat folder jika belum ada
    if (!is_dir($uploadDir)) {
        @mkdir($uploadDir, 0755, true);
    }

    // Cek lagi (kalau gagal buat)
    if (!is_dir($uploadDir)) {
        echo json_encode([
            'status'       => FALSE,
            'inputerror'   => ['file'],
            'error_string' => ['Folder uploads tidak ditemukan & gagal dibuat. Periksa path/permission.']
        ]);
        exit();
    }

    // Cek tulis
    if (!is_writable($uploadDir)) {
        echo json_encode([
            'status'       => FALSE,
            'inputerror'   => ['file'],
            'error_string' => ['Folder uploads tidak bisa ditulis. Set permission 755/775.']
        ]);
        exit();
    }

    $config['upload_path']      = $uploadDir;
    $config['allowed_types']    = 'pdf|PDF';
    $config['max_size']         = 0;
    $config['file_name']        = random_string('alnum', 50) . $date->getTimestamp();
    $config['file_ext_tolower'] = TRUE;
    $config['detect_mime']      = TRUE;

    $this->load->library('upload', $config);

    if (!$this->upload->do_upload('file')) {
        $err = strip_tags($this->upload->display_errors('', ''));
        echo json_encode([
            'status'       => FALSE,
            'inputerror'   => ['file'],
            'error_string' => [$err ?: 'Upload gagal. Pastikan file PDF & ukuran tidak melebihi batas.']
        ]);
        exit();
    }

    // Kembalikan hanya nama file; simpan di DB seperti biasa
    return $this->upload->data('file_name');
}



	private function validate()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        if ($this->input->post('file') == '') {
            $data['inputerror'][] = 'file';
            $data['error_string'][] = 'Berkas harus diisi';
            $data['status'] = FALSE;
        }

       if ($data['status'] === FALSE) {
            echo json_encode($data);
            exit();
        }
    }

   


}
