<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Validasi_satpam extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Login_model');
		$this->load->model('kehadiran_satpam_model');
        $this->load->helper('Rupiah_helper');
		$this->load->helper('string');
		$this->load->library('Pdf'); 
	}

    public function decrypt_url($string) {
        $key = '874jzceroier38!@#%*bjkdwdw)'; // Ganti dengan kunci enkripsi yang diinginkan
        $string = str_replace(array('-', '_'), array('+', '/'), $string);
        $string = base64_decode($string);
        $string = str_replace($key, '', $string);
        return $string;
    }

	public function koreksi_satpam($id){
		$this->Login_model->getsqurity() ;
        $decrypted_id = $this->decrypt_url($id);
        $bulan = $this->db->query("select bulan, tahun from kehadiran_lembaga where id_kehadiran_lembaga = $decrypted_id")->row();
        $sql = "
            SELECT 
                ks.id_kehadiran_satpam,
                kl.status,
                u.gelar_depan,
                u.gelar_belakang,
                kl.file,
                kl.id_kehadiran_lembaga,
                u.nama_lengkap,
                ks.bulan,
                ks.tahun,
                SUM(ks.jumlah_hari) AS jumlah_hari,
                SUM(ks.jumlah_shift) AS jumlah_shift,
                SUM(ks.jumlah_dinihari) AS jumlah_dinihari,
                t.nominal_transport,
                s.id_satpam
            FROM kehadiran_satpam ks
            JOIN kehadiran_lembaga kl 
                ON kl.id_kehadiran_lembaga = ks.id_kehadiran_lembaga
            JOIN satpam s 
                ON s.id_satpam = ks.id_satpam
            JOIN umana u 
                ON u.nik = s.nik
            JOIN transport t 
                ON t.id_transport = s.id_transport
            JOIN lembaga l 
                ON l.id_lembaga = kl.id_lembaga
            WHERE 
                l.id_lembaga = '58'
                AND DATEDIFF(NOW(), s.tgl_mulai) < s.tgl_selesai
                AND kl.id_kehadiran_lembaga = ?
            GROUP BY 
                u.nik, u.nama_lengkap, ks.bulan, ks.tahun
            ORDER BY 
                u.nama_lengkap ASC
        ";

        $list = $this->db->query($sql, [$decrypted_id])->result();
		$no = 1;
		$isi['id'] 	= $id;
		$isi['bulan']  = $bulan;
		$isi['isilist']  = $list;
		$this->load->view('Validasi_fullscreen/Validasi_satpam',$isi);
	}

    public function save_data() {
		$id_satpam = $this->input->post('id_satpam');
		$id_kehadiran_satpam = $this->input->post('id_kehadiran_satpam');
		$id_kehadiran_lembaga = $this->input->post('id_kehadiran_lembaga');
		$bulan = $this->input->post('bulan');
        $tahun = $this->input->post('tahun');
		$jumlah_hari = $this->input->post('jumlah_hari');
        $nominal_transport = $this->input->post('nominal_transport');
        $jumlah_transport = $this->input->post('jumlah_transport');
		$jumlah_shift = $this->input->post('jumlah_shift');
        $rank = $this->input->post('rank');
        $jumlah_barokah = $this->input->post('jumlah_barokah');
		$jumlah_dinihari = $this->input->post('jumlah_dinihari');
		$konsumsi = $this->input->post('konsumsi');
        $jumlah_konsumsi = $this->input->post('jumlah_konsumsi');
		$diterima = $this->input->post('diterima');
		$jumlah_total = $this->input->post('jumlah_total');
		
		for ($i = 0; $i < count($bulan); $i++) {
		  $data = array(
			'id_total_barokah_satpam' => '',
			'id_satpam' => $id_satpam[$i],
			'id_kehadiran_satpam' => $id_kehadiran_satpam[$i],
            'id_kehadiran_lembaga' => $id_kehadiran_lembaga,
			'bulan' => $bulan[$i],
			'tahun' => $tahun[$i],
			'jumlah_hari' => $jumlah_hari[$i],
            'nominal_transport' => $nominal_transport[$i],
            'jumlah_transport' => $jumlah_transport[$i],
            'jumlah_shift' => $jumlah_shift[$i],
            'rank' => $rank[$i],
            'jumlah_barokah' => $jumlah_barokah[$i],
            'jumlah_dinihari' => $jumlah_dinihari[$i],
            'konsumsi' => $konsumsi[$i],
            'jumlah_konsumsi' => $jumlah_konsumsi[$i],
			'diterima' => $diterima[$i]
		  );
		  $this->db->insert('total_barokah_satpam', $data);
		}
		$data2 = array(
			'status' => "acc",
			'jumlah_total' => $jumlah_total
		  );

		$this->db->where('id_kehadiran_lembaga', $id_kehadiran_lembaga);
		$this->db->update('kehadiran_lembaga', $data2);
        echo json_encode(['status' => true]);
        exit;
		
	}


}